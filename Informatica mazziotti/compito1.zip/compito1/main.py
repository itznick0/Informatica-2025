import os
import sys
import subprocess
os.chdir(os.path.dirname(os.path.abspath(__file__)))
print(f"Python sta partendo da: {os.getcwd()}")
java_path = './compito05_11/src'

compile = ['javac', '-d', './compito05_11/bin', 'App.java']

compile_process = subprocess.run(
    compile,
    cwd=java_path,
    capture_output=True,
    text=True
)

if compile_process.returncode != 0:
    print("Impossibil compilare")
    sys.exit()

class_path = './compito05_11/bin'

execution = ['java', 'App', '123']

result = subprocess.run(
    execution,
    cwd=class_path,
    capture_output=True,
    text=True
)

print(result.stdout)

if result.stderr:
    print(f"errors: {result.stderr}")